
Chapter 30. Network Chat

From:
  Killer Game Programming in Java
  Andrew Davison
  O'Reilly, May 2005
  ISBN: 0-596-00730-2
  http://www.oreilly.com/catalog/killergame/
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th

If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew

---------

There are three directories, holding three different versions of a
chat application.

Threaded:	Threaded TCP Clients and Server

Multicasting:	UDP Multicasting Clients and a Name Server

ChatServlet:	Clients using a Servlet as a Server


The examples are set up to run on the same machine
(i.e. the server's address is localhost).

---------
Last updated: 20th April 2005

