Used MetaCreations Poser 3

Used "Additional Figures" Stick Child

Switched on IK on arms and legs.

punch1.3ds, punch2.3ds
  - fighting set: reverse punch and used symmetry swapping on arms

stand.3ds
  - creative pose set: hulk pose

walk1.3ds, walk2.3ds
  - walk designer: walk
    and used symmetry on arms and legs

rev1.3ds, rev2.3ds
  - standing sets: wait
    and used symmetry on arms and legs

Each file is about 20K.
