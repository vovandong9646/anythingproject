
Appendix B. Installation using Java Web Start

From:
  Killer Game Programming in Java
  Andrew Davison
  O'Reilly, May 2005
  ISBN: 0-596-00730-2
  http://www.oreilly.com/catalog/killergame/
  Web Site for the book: http://fivedots.coe.psu.ac.th/~ad/jg

Contact Address:
  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th

If you use this code, please mention my name, and include a link
to the book's Web site.

Thanks,
  Andrew


============================
This directory contains:

*  BugRunner/        // directory for the BugRunner JWS example
*  Checkers3D/       // directory for the Checkers3D JWS example

   Please look at the readme files in those directories.

*  a copy of the JWS portal page, index.html
   The original is at: http://fivedots.coe.psu.ac.th/~ad/jws

-----
Last updated: 20th April 2005

